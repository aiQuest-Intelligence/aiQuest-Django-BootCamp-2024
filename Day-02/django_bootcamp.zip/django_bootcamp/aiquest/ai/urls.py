from django.urls import path
from . import views

urlpatterns = [
    path('',views.course),
    path('teacher/',views.paid_course),
]
from django.shortcuts import render
from . models import Teacher

# Create your views here.
def course(request):
    return render(request, 'course.html')

def paid_course(request):
    info = Teacher.objects.all()
    return render(request, 'paid_course.html', {'teacher':info})
